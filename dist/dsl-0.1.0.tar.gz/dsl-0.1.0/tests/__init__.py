"""
DSL Framework Test Suite
"""
